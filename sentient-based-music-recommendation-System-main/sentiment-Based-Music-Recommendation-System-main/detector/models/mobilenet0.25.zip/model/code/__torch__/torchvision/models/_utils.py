class IntermediateLayerGetter(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  stage1 : __torch__.torch.nn.modules.container.___torch_mangle_35.Sequential
  stage2 : __torch__.torch.nn.modules.container.___torch_mangle_78.Sequential
  stage3 : __torch__.torch.nn.modules.container.___torch_mangle_93.Sequential
  def forward(self: __torch__.torchvision.models._utils.IntermediateLayerGetter,
    inputs: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    stage3 = self.stage3
    stage2 = self.stage2
    stage1 = self.stage1
    _0 = (stage1).forward(inputs, )
    _1 = (stage2).forward(_0, )
    return (_0, _1, (stage3).forward(_1, ))
