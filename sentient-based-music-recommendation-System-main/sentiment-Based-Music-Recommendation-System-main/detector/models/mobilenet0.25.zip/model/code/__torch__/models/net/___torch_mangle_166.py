class SSH(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv3X3 : __torch__.torch.nn.modules.container.___torch_mangle_151.Sequential
  conv5X5_1 : __torch__.torch.nn.modules.container.___torch_mangle_155.Sequential
  conv5X5_2 : __torch__.torch.nn.modules.container.___torch_mangle_158.Sequential
  conv7X7_2 : __torch__.torch.nn.modules.container.___torch_mangle_162.Sequential
  conv7x7_3 : __torch__.torch.nn.modules.container.___torch_mangle_165.Sequential
  def forward(self: __torch__.models.net.___torch_mangle_166.SSH,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    conv7x7_3 = self.conv7x7_3
    conv7X7_2 = self.conv7X7_2
    conv5X5_2 = self.conv5X5_2
    conv5X5_1 = self.conv5X5_1
    conv3X3 = self.conv3X3
    _0 = (conv3X3).forward(argument_1, )
    _1 = (conv5X5_1).forward(argument_2, )
    _2 = (conv5X5_2).forward(_1, )
    _3 = (conv7x7_3).forward((conv7X7_2).forward(_1, ), )
    input = torch.cat([_0, _2, _3], 1)
    return torch.relu(input)
