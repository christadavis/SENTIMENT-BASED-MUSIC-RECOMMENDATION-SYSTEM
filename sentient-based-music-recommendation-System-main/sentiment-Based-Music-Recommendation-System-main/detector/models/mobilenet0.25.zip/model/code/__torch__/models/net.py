class FPN(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  output1 : __torch__.torch.nn.modules.container.___torch_mangle_97.Sequential
  output2 : __torch__.torch.nn.modules.container.___torch_mangle_101.Sequential
  output3 : __torch__.torch.nn.modules.container.___torch_mangle_105.Sequential
  merge1 : __torch__.torch.nn.modules.container.___torch_mangle_109.Sequential
  merge2 : __torch__.torch.nn.modules.container.___torch_mangle_113.Sequential
  def forward(self: __torch__.models.net.FPN,
    argument_1: Tensor,
    argument_2: Tensor,
    argument_3: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    merge1 = self.merge1
    merge2 = self.merge2
    output3 = self.output3
    output2 = self.output2
    output1 = self.output1
    _0 = (output1).forward(argument_1, )
    _1 = (output2).forward(argument_2, )
    _2 = (output3).forward(argument_3, )
    _3 = ops.prim.NumToTensor(torch.size(_1, 2))
    _4 = int(_3)
    _5 = ops.prim.NumToTensor(torch.size(_1, 3))
    up3 = torch.upsample_nearest2d(_2, [_4, int(_5)], None)
    input = torch.add(_1, up3)
    _6 = (merge2).forward(input, )
    _7 = ops.prim.NumToTensor(torch.size(_0, 2))
    _8 = int(_7)
    _9 = ops.prim.NumToTensor(torch.size(_0, 3))
    up2 = torch.upsample_nearest2d(_6, [_8, int(_9)], None)
    input0 = torch.add(_0, up2)
    _10 = ((merge1).forward(input0, ), _6, _6, _2, _2)
    return _10
class SSH(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv3X3 : __torch__.torch.nn.modules.container.___torch_mangle_116.Sequential
  conv5X5_1 : __torch__.torch.nn.modules.container.___torch_mangle_120.Sequential
  conv5X5_2 : __torch__.torch.nn.modules.container.___torch_mangle_123.Sequential
  conv7X7_2 : __torch__.torch.nn.modules.container.___torch_mangle_127.Sequential
  conv7x7_3 : __torch__.torch.nn.modules.container.___torch_mangle_130.Sequential
  def forward(self: __torch__.models.net.SSH,
    argument_1: Tensor) -> Tensor:
    conv7x7_3 = self.conv7x7_3
    conv7X7_2 = self.conv7X7_2
    conv5X5_2 = self.conv5X5_2
    conv5X5_1 = self.conv5X5_1
    conv3X3 = self.conv3X3
    _11 = (conv3X3).forward(argument_1, )
    _12 = (conv5X5_1).forward(argument_1, )
    _13 = (conv5X5_2).forward(_12, )
    _14 = (conv7x7_3).forward((conv7X7_2).forward(_12, ), )
    input = torch.cat([_11, _13, _14], 1)
    return torch.relu(input)
