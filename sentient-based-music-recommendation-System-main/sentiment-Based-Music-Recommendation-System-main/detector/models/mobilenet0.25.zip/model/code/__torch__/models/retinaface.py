class RetinaFace(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  body : __torch__.torchvision.models._utils.IntermediateLayerGetter
  fpn : __torch__.models.net.FPN
  ssh1 : __torch__.models.net.SSH
  ssh2 : __torch__.models.net.___torch_mangle_148.SSH
  ssh3 : __torch__.models.net.___torch_mangle_166.SSH
  ClassHead : __torch__.torch.nn.modules.container.ModuleList
  BboxHead : __torch__.torch.nn.modules.container.___torch_mangle_177.ModuleList
  LandmarkHead : __torch__.torch.nn.modules.container.___torch_mangle_183.ModuleList
  def forward(self: __torch__.models.retinaface.RetinaFace,
    inputs: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    LandmarkHead = self.LandmarkHead
    _2 = getattr(LandmarkHead, "2")
    LandmarkHead0 = self.LandmarkHead
    _1 = getattr(LandmarkHead0, "1")
    LandmarkHead1 = self.LandmarkHead
    _0 = getattr(LandmarkHead1, "0")
    ClassHead = self.ClassHead
    _20 = getattr(ClassHead, "2")
    ClassHead0 = self.ClassHead
    _10 = getattr(ClassHead0, "1")
    ClassHead1 = self.ClassHead
    _00 = getattr(ClassHead1, "0")
    BboxHead = self.BboxHead
    _21 = getattr(BboxHead, "2")
    BboxHead0 = self.BboxHead
    _11 = getattr(BboxHead0, "1")
    BboxHead1 = self.BboxHead
    _01 = getattr(BboxHead1, "0")
    ssh3 = self.ssh3
    ssh2 = self.ssh2
    ssh1 = self.ssh1
    fpn = self.fpn
    body = self.body
    _3, _4, _5, = (body).forward(inputs, )
    _6, _7, _8, _9, _12, = (fpn).forward(_3, _4, _5, )
    _13 = (ssh1).forward(_6, )
    _14 = (ssh2).forward(_7, _8, )
    _15 = (ssh3).forward(_9, _12, )
    _16 = [(_01).forward(_13, ), (_11).forward(_14, ), (_21).forward(_15, )]
    _17 = torch.cat(_16, 1)
    _18 = [(_00).forward(_13, ), (_10).forward(_14, ), (_20).forward(_15, )]
    input = torch.cat(_18, 1)
    _19 = [(_0).forward(_13, ), (_1).forward(_14, ), (_2).forward(_15, )]
    _22 = torch.cat(_19, 1)
    _23 = (_17, torch.softmax(input, -1), _22)
    return _23
class ClassHead(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1x1 : __torch__.torch.nn.modules.conv.___torch_mangle_167.Conv2d
  def forward(self: __torch__.models.retinaface.ClassHead,
    argument_1: Tensor) -> Tensor:
    conv1x1 = self.conv1x1
    _17 = torch.permute((conv1x1).forward(argument_1, ), [0, 2, 3, 1])
    out = torch.contiguous(_17)
    _18 = ops.prim.NumToTensor(torch.size(out, 0))
    return torch.view(out, [int(_18), -1, 2])
class BboxHead(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1x1 : __torch__.torch.nn.modules.conv.___torch_mangle_172.Conv2d
  def forward(self: __torch__.models.retinaface.BboxHead,
    argument_1: Tensor) -> Tensor:
    conv1x1 = self.conv1x1
    _19 = torch.permute((conv1x1).forward(argument_1, ), [0, 2, 3, 1])
    out = torch.contiguous(_19)
    _20 = ops.prim.NumToTensor(torch.size(out, 0))
    return torch.view(out, [int(_20), -1, 4])
class LandmarkHead(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1x1 : __torch__.torch.nn.modules.conv.___torch_mangle_178.Conv2d
  def forward(self: __torch__.models.retinaface.LandmarkHead,
    argument_1: Tensor) -> Tensor:
    conv1x1 = self.conv1x1
    _21 = torch.permute((conv1x1).forward(argument_1, ), [0, 2, 3, 1])
    out = torch.contiguous(_21)
    _22 = ops.prim.NumToTensor(torch.size(out, 0))
    return torch.view(out, [int(_22), -1, 10])
