class LandmarkHead(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  conv1x1 : __torch__.torch.nn.modules.conv.___torch_mangle_181.Conv2d
  def forward(self: __torch__.models.retinaface.___torch_mangle_182.LandmarkHead,
    argument_1: Tensor) -> Tensor:
    conv1x1 = self.conv1x1
    _0 = torch.permute((conv1x1).forward(argument_1, ), [0, 2, 3, 1])
    out = torch.contiguous(_0)
    _1 = ops.prim.NumToTensor(torch.size(out, 0))
    return torch.view(out, [int(_1), -1, 10])
